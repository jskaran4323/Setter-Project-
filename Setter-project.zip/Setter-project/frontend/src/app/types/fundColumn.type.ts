import { Fund } from "./fund.type";

export type FundColumn = {
    key: keyof Fund;
    label: string;
  };