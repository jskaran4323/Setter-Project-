import { Routes } from '@angular/router';
import { IndexComponent } from './pages/index/index.component';
import { FundsTableComponent } from './pages/funds-table/funds-table.component';
import { FundDetailComponent } from './pages/funds-details/fund-details.component';
import { FundEditComponent } from './pages/fund-edit/fund-edit.component';



export const routes: Routes = [
    { path: '', component: FundsTableComponent },
    { path: 'fund/:name', component: FundDetailComponent },
    { path: 'admin/edit/:name', component: FundEditComponent },
    { path: 'index', component: IndexComponent},
    { path: '**', redirectTo: 'index'}
];
