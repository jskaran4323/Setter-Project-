import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Fund } from '../types/fund.type';


@Injectable({
  providedIn: 'root'
})
export class FundService {
  private http = inject(HttpClient);
  //since we only have funds api, i have took base url like this
  //if we have more than only http://localhost:3000/api
  private baseUrl = 'http://localhost:3000/api/funds';

  getAllFunds() {
    return this.http.get<Fund[]>(`${this.baseUrl}/all`);
  }

  getFundByName(name: string) {
    return this.http.get<Fund>(`${this.baseUrl}/${encodeURIComponent(name)}`);
  }

  updateFund(name: string, fund: Fund) {
    return this.http.put<Fund>(`${this.baseUrl}/${encodeURIComponent(name)}`, fund);
  }

  deleteFund(name: string) {
    return this.http.delete(`${this.baseUrl}/${encodeURIComponent(name)}`);
  }
}

export type { Fund };
