import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import {  FundService } from '../../services/fund.service';
import { Fund } from 'src/app/types/fund.type';
@Component({
  selector: 'app-fund-edit',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './fund-edit.component.html',
  styleUrl: './fund-edit.component.scss'
})
export class FundEditComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private fundService = inject(FundService);

  originalName = '';
  fund: Fund | null = null;
  loading = true;
  error = '';
  saving = false;
  saveMessage = '';
  // since we have to bar to show success.
  delete = false;
  deleteMessage = '';


  ngOnInit(): void {
    const name = this.route.snapshot.paramMap.get('name');

    if (!name) {
      this.error = 'Fund name missing';
      this.loading = false;
      return;
    }

    this.originalName = name;

    this.fundService.getFundByName(name).subscribe({
      next: (data) => {
        this.fund = { ...data };
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.error = "Fund not found. Redirecting...";
        setTimeout(() => {
        this.router.navigate(['/']);
         }, 1500);
      }
    });
  }

  autoSave() {
    if (!this.fund) return;

    this.saving = true;
    this.saveMessage = '';

    this.fundService.updateFund(this.originalName, this.fund).subscribe({
      next: () => {
        this.saving = false;
        this.saveMessage = 'Changes saved';
        this.originalName = this.fund?.name || this.originalName;
      },
      error: () => {
        this.saving = false;
        this.saveMessage = 'Save failed';
      }
    });
  }

  updateArrayField(field: 'strategies' | 'geographies' | 'managers', value: string) {
    if (!this.fund) return;
    this.fund[field] = value.split(',').map(v => v.trim()).filter(Boolean);
  }

  deleteFund() {
    if (!this.fund) return;
    this.delete = true;
    this.deleteMessage = "";
    this.fundService.deleteFund(this.originalName).subscribe({
      next: () => {
        this.delete = false;
        // this message will show on top.
        this.deleteMessage = "Funds deleted successfully"
        // use any side bar to display this
        //since we have to side bar this is to imitate that funds deleted succussfully
        //will go to main view after 1.5 sec 
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 1500);
      },
      error: () => {
        this.error = 'Delete failed';
      }
    });
  }
  
  backToFund(name: string){
    this.router.navigate(['/fund', name])
  }

  getArrayString(value: string[] | undefined) {
    return value?.join(', ') || '';
  }
}