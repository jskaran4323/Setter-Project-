import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FundService } from '../../services/fund.service';
import { Fund } from 'src/app/types/fund.type';
import { FundColumn } from 'src/app/types/fundColumn.type';

@Component({
  selector: 'app-funds-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './funds-table.component.html',
  styleUrl: './funds-table.component.scss'
})
export class FundsTableComponent implements OnInit {
  private fundService = inject(FundService);
  private router = inject(Router);


  columns: FundColumn[] = [
    { key: 'name', label: 'Name' },
    { key: 'strategies', label: 'Strategies' },
    { key: 'geographies', label: 'Geographies' },
    { key: 'currency', label: 'Currency' },
    { key: 'fundSize', label: 'Fund Size' },
    { key: 'vintage', label: 'Vintage' },
    { key: 'managers', label: 'Managers' }
  ];

  funds: Fund[] = [];
  loading = true;
  error = '';

  ngOnInit(): void {
    this.fundService.getAllFunds().subscribe({
      next: (data) => {
        this.funds = data;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load funds';
        this.loading = false;
      }
    });
  }

  goToDetail(name: string) {
    this.router.navigate(['/fund', name],{ replaceUrl: true });
  }

  goToEdit(name: string, event: Event) {
    event.stopPropagation();
    this.router.navigate(['/admin/edit', name], {replaceUrl: true});
  }

  getCellValue(fund: Fund, key: keyof Fund): string | number {
    const value = fund[key];
    return Array.isArray(value) ? value.join(', ') : value;
  }
}