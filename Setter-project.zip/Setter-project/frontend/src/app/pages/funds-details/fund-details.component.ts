import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FundService } from '../../services/fund.service';
import { Fund } from 'src/app/types/fund.type';
@Component({
  selector: 'app-fund-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './fund-details.component.html',
  styleUrl: './fund-details.component.scss'
})
export class FundDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private fundService = inject(FundService);

  fund: Fund | null = null;
  loading = true;
  error = '';

  ngOnInit(): void {
    const name = this.route.snapshot.paramMap.get('name');

    if (!name) {
      this.router.navigate(['/']); 
      return;
    }

    this.fundService.getFundByName(name).subscribe({
      next: (data) => {
        this.fund = data;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.error = "Fund not found. Redirecting...";
        //if we counted any error we imitate a loading call and go back to the main view
        setTimeout(() => {
        this.router.navigate(['/']);
         }, 1000);
      }
    });
  }
}