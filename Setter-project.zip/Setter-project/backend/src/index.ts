import express, { Request, Response, Express } from 'express';
import cors from "cors";

import { registerRoutes } from './routes';

const app: Express = express();
const port = process.env.PORT || 3000; // since no .env file is being used so 3000 port is working.

app.use(express.json());

// added this node package for CORS.
app.use(cors());

//All registers routes starts from here
registerRoutes(app)


app.get('/', (req: Request, res: Response) => {
  res.send('Hello, TypeScript with Express!');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});