import { Request, Response, NextFunction } from "express";
import {
  getAllFunds,
  getFundByName,
  updateFundByName,
  deleteFundByName,
} from "../services/fund.service";

export const getFunds = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const fundData = await getAllFunds();
    res.status(200).json(fundData);
  } catch (error) {
    next(error);
  }
};

export const getSingleFund = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { name } = req.params;
    const fund = await getFundByName(name);
    res.status(200).json(fund);
  } catch (error) {
    next(error);
  }
};


export const editSingleFund = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { name } = req.params;
    const updatedFund = await updateFundByName(name, req.body);
    res.status(200).json(updatedFund);
  } catch (error) {
    next(error);
  }
};


export const deleteFund = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { name } = req.params;
    const deletedFund = await deleteFundByName(name);

    res.status(200).json({
      message: "Fund deleted successfully",
      data: deletedFund,
    });
  } catch (error) {
    next(error);
  }
};