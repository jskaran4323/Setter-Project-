import fs from "fs/promises";
import path from "path";
import { AppError } from "../utils/AppError";
import { Fund } from "../types/fund";


const filePath = path.join(process.cwd(), "data", "funds_data.json");

async function readFundsFile(): Promise<Fund[]> {
  try {
    const data = await fs.readFile(filePath, "utf-8");
    const jsonData: Fund[] = JSON.parse(data);
    return jsonData;
  } catch (error) {
    throw new AppError("Error reading or parsing file", 500);
  }
}

async function writeFundsFile(funds: Fund[]): Promise<void> {
  try {
    await fs.writeFile(filePath, JSON.stringify(funds, null, 2), "utf-8");
  } catch (error) {
    throw new AppError("Error writing file", 500);
  }
}

export async function getAllFunds(): Promise<Fund[]> {
  return await readFundsFile();
}

export async function getFundByName(name: string): Promise<Fund> {
  const funds = await readFundsFile();
  const fund = funds.find(
    (f) => f.name.toLowerCase().trim() === name.toLowerCase().trim()
  );
  
  if (!fund) {
    throw new AppError("Fund not found", 404);
  }
  return fund;
}

export async function updateFundByName(
  name: string,
  updatedData: Partial<Fund>
): Promise<Fund> {
  const funds = await readFundsFile();

  const index = funds.findIndex(
    (f) => f.name.toLowerCase().trim() === name.toLowerCase().trim()
  );
  if (index === -1) {
    throw new AppError("Fund not found", 404);
  }
  funds[index] = {
    ...funds[index],
    ...updatedData,
  };

  await writeFundsFile(funds);

  return funds[index];
}

export async function deleteFundByName(name: string): Promise<Fund> {
  const funds = await readFundsFile();

  const index = funds.findIndex(
    (f) => f.name.toLowerCase().trim() === name.toLowerCase().trim()
  );

  if (index === -1) {
    throw new AppError("Fund not found", 404);
  }

  const deletedFund = funds[index];
  const updatedFunds = funds.filter(
    (f) => f.name.toLowerCase().trim() !== name.toLowerCase().trim()
  );

  await writeFundsFile(updatedFunds);

  return deletedFund;
}