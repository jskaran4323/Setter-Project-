
import { Express } from 'express';
import fundRoutes from './fund.routes';


export const registerRoutes = (app: Express): void => {
  const baseUrl = `/api`;
  app.use(`${baseUrl}/funds`, fundRoutes)
};
