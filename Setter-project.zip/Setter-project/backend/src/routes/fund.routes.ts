import express from 'express'
import { deleteFund, editSingleFund, getSingleFund, getFunds } from '../controller/fund.controller'

const router = express.Router()

router.get("/all", getFunds)
router.get("/:name", getSingleFund)
router.put("/:name",editSingleFund)
router.delete("/:name", deleteFund)
export default router;