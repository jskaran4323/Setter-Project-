# Backend

## Start the application:
Run below scripts
```
npm run tsc
npm run start

```

Run below scripts if above one does't work
```
npm run dev
```




